// import { useEffect, useState } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
// import axios from "axios";  

import { useEffect, useState } from "react";
import { Card, CardContent }   from "./components/ui/card";
import { Button }              from "./components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
}                              
from "./components/ui/table";
import axios from "axios";
// CSS-based Map Component (no image dependencies)
const TexasMap = ({ locations }) => {
    // Predefined positions for major Texas cities
    const cityPositions = {
      Austin: { left: '30%', top: '50%' },
      Dallas: { left: '45%', top: '30%' },
      Houston: { left: '55%', top: '60%' },
      'San Antonio': { left: '35%', top: '65%' },
      'El Paso': { left: '10%', top: '50%' }
    };
  
    return (
      <div className="relative w-full h-full bg-gray-50 rounded-md border border-gray-200">
        {/* Texas outline */}
        <div className="absolute inset-0">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Simplified Texas shape */}
            <path 
              d="M15,10 L85,10 L95,35 L85,60 L65,80 L35,85 L15,75 L5,50 Z" 
              fill="#f8fafc" 
              stroke="#cbd5e1" 
              strokeWidth="1"
            />
          </svg>
        </div>
        
        {/* Markers */}
        {locations.map((location) => (
          <div 
            key={location.city}
            className={`absolute w-4 h-4 rounded-full ${
              location.status === "Active" ? "bg-green-500" : "bg-gray-400"
            } border-2 border-white transform -translate-x-1/2 -translate-y-1/2 
            hover:scale-150 transition-all duration-200 group`}
            style={cityPositions[location.city]}
          >
            {/* Tooltip */}
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 bg-white px-2 py-1 rounded shadow-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-10">
              <strong>{location.city}</strong>
              <div>Status: {location.status}</div>
              <div>Bins: {location.bins}</div>
            </div>
          </div>
        ))}
        
        {/* Legend */}
        <div className="absolute bottom-2 left-2 bg-white/80 backdrop-blur-sm p-2 rounded text-xs shadow-sm">
          <div className="flex items-center mb-1">
            <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
            Active
          </div>
          <div className="flex items-center">
            <span className="w-3 h-3 rounded-full bg-gray-400 mr-2"></span>
            Planned/Pilot
          </div>
        </div>
      </div>
    );
  };

export default function SmartBinDashboard() {
  const [logs, setLogs] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  // Mock data for smart bin locations in Texas
  const smartBinLocations = [
    { 
      city: "Austin", 
      coords: [30.2672, -97.7431], 
      status: "Active", 
      bins: 45,
      lastUpdated: "2023-11-15"
    },
    { 
      city: "Dallas", 
      coords: [32.7767, -96.7970], 
      status: "Active", 
      bins: 32,
      lastUpdated: "2023-11-14"
    },
    { 
      city: "Houston", 
      coords: [29.7604, -95.3698], 
      status: "Active", 
      bins: 58,
      lastUpdated: "2023-11-16"
    },
    { 
      city: "San Antonio", 
      coords: [29.4241, -98.4936], 
      status: "Pilot", 
      bins: 12,
      lastUpdated: "2023-11-10"
    },
    { 
      city: "El Paso", 
      coords: [31.7619, -106.4850], 
      status: "Planned", 
      bins: 0,
      lastUpdated: "N/A"
    }
  ];

  const fetchLogs = async () => {
    try {
      setRefreshing(true);
      const res = await axios.get("https://script.google.com/macros/s/AKfycbym24Ynh29rKtA1PciyntDak7kWtQyGZMVjobE_v3VnISIdYkh4lwtU_3Y2-BlL3XFb/exec", {
        redirect: "follow",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
    // Get only the first 5 most recent logs
    const recentLogs = res.data.slice(0, 5);
    setLogs(recentLogs);
  } catch (err) {
    console.error("Error fetching logs:", err);
  } finally {
    setRefreshing(false);
  }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  return (
    <div className="table-container">
      <h1 className="text-2xl font-bold">Smart Dustbin Dashboard</h1>
      <Button onClick={fetchLogs} disabled={refreshing}>
        {refreshing ? "Refreshing..." : "Refresh Data"}
      </Button>
      <Card>
        <CardContent>
          <h2 className="text-xl mb-4 font-semibold">Trash Logs</h2>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                {/* <TableHead>Time</TableHead> */}
                <TableHead>Temperature</TableHead>
                <TableHead>Humidity</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.length > 0 ? (
                logs.map((log, index) => (
                  <TableRow key={index}>
                    <TableCell>{log.Date}</TableCell>
                    {/* <TableCell>{log.Time}</TableCell> */}
                    <TableCell>{log.Temperature}</TableCell>
                    <TableCell>{log.Humidity}</TableCell>
                    <TableCell>{log.Status}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4}>No data available</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      {/* Map Card */}
      {/* Texas Map */}
        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl mb-4 font-semibold">Smart Bin Locations</h2>
            <div className="h-[400px]">
              <TexasMap locations={smartBinLocations} />
            </div>
          </CardContent>
        </Card>
    </div>
  );
}
